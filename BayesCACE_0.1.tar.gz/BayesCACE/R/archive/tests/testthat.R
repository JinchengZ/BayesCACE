library(testthat)
library(BayesCACE)

test_check("BayesCACE")
