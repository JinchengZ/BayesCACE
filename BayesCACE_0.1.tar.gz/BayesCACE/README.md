# BayesCACE
Estimating Causal Effect using the Bayesian Method in a Single Study or Meta-Analysis
